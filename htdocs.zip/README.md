Tixzoo website

bash build-bucket.sh foldername
