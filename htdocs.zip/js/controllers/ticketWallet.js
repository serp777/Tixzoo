App.TicketWalletController = Ember.Controller.extend({

});