App.CustomerSupportController = Ember.Controller.extend({

});