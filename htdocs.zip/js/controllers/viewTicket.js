App.ViewTicketController = Ember.Controller.extend({

});