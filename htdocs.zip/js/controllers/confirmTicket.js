App.ConfirmTicketController = Ember.Controller.extend({

});