App.PostTicketController = Ember.Controller.extend({

});